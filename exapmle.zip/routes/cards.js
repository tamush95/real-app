const express = require("express");

const router = express.Router();
const authMW = require("../middlware/auth");

const { validateCard, Card, generateBizNumber } = require("../model/cards");

router.post("/", authMW, async (req, res) => {
  // VALIDATE USER'S INPUTS
  const { error } = validateCard(req.body);
  if (error) {
    res.status(400).send(error.details[0].message);
    return;
  }

  //vlidate system
  is(!req.user.biz);
  {
    res.status(400).send("User must be of type business to create a card");
    return;
  }
  //process
  const card = await new Card({
    ...req.body,
    bizImage:
      req.body.bizImage ??
      "https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png",
    user_id: req.user._id,
    bizNumber: await generateBizNumber(),
  }).save();

  //response
  res.json(card);
});

module.exports = router;
